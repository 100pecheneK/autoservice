from django.contrib import admin
from .models import Clients

admin.site.register(Clients)
