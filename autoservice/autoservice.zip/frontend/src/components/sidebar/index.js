import VerticalSidebar from "./sidebar"

export default VerticalSidebar