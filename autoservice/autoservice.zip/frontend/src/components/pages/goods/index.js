import GoodsPage from "./goodsPage"

export default GoodsPage