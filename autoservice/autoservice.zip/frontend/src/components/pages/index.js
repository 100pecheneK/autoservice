import AccountsPage from "./accounts"
import ClientsPage from "./clients"
import GoodsPage from "./goods"
import HomePage from "./home"
import Orders from "./orders"

export {
    AccountsPage,
    ClientsPage,
    GoodsPage,
    HomePage,
    Orders,
}