import ClientsPage from "./clientsPage"

export default ClientsPage