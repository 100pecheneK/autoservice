import AccountsPage from "./accountsPage"

export default AccountsPage