import Orders from "./orders"

export default Orders