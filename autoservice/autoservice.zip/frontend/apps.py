from django.apps import AppConfig


class FrontendConfig(AppConfig):
    name = 'frontend'
